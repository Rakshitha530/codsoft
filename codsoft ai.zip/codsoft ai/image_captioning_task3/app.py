from model import generate_caption
from utils import load_image, show_image

if __name__ == "__main__":
    image_path = "images/sample.jpg"
    image = load_image(image_path)
    caption = generate_caption(image)
    print("Generated Caption:", caption)
    show_image(image_path, caption)