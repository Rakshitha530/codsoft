import utils
import os

# Load known faces
print("Loading known faces...")
known_face_encodings, known_face_names = utils.load_known_faces("known_faces")

# Test on new images
for img_name in os.listdir("test_images"):
    path = os.path.join("test_images", img_name)
    utils.recognize_faces(path, known_face_encodings, known_face_names)