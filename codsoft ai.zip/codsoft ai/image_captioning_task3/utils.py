from tensorflow.keras.applications.resnet50 import preprocess_input
from tensorflow.keras.preprocessing import image
import numpy as np
import matplotlib.pyplot as plt

def load_image(img_path):
    img = image.load_img(img_path, target_size=(224, 224))
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    return preprocess_input(x)

def show_image(img_path, caption):
    img = image.load_img(img_path)
    plt.imshow(img)
    plt.title(caption)
    plt.axis('off')
    plt.show()