
def chatbot_response(user_input):
    user_input = user_input.lower()
    
    if "hello" in user_input or "hi" in user_input:
        return "Hello! How can I assist you today?"
    elif "how are you" in user_input:
        return "I'm just a program, but I'm doing fine. How about you?"
    elif "bye" in user_input:
        return "Goodbye! Have a great day!"
    elif "your name" in user_input:
        return "I am a simple rule-based chatbot created for CODSOFT internship."
    else:
        return "I'm sorry, I don't understand that. Can you please rephrase?"

# Main loop
if __name__ == "__main__":
    print("Welcome to CODSOFT Chatbot! Type 'bye' to exit.")
    while True:
        user_input = input("You: ")
        if "bye" in user_input.lower():
            print("Bot:", chatbot_response(user_input))
            break
        else:
            print("Bot:", chatbot_response(user_input))
