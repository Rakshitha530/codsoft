from recommender import recommend_movies

if __name__ == "__main__":
    movie = input("Enter a movie title: ")
    recommendations = recommend_movies(movie)
    print("\nRecommended Movies:")
    for rec in recommendations:
        print("-", rec)