from tensorflow.keras.applications.resnet50 import ResNet50
from tensorflow.keras.models import Model
from tensorflow.keras.preprocessing.sequence import pad_sequences

# Dummy tokenizer and model for demonstration
tokenizer = {
    'startseq': 1, 'endseq': 2, 'a': 3, 'man': 4, 'riding': 5, 'bike': 6
}
inv_tokenizer = {v: k for k, v in tokenizer.items()}

def extract_features(img):
    model = ResNet50(weights="imagenet")
    model = Model(inputs=model.input, outputs=model.layers[-2].output)
    features = model.predict(img, verbose=0)
    return features

def generate_caption(img):
    features = extract_features(img)
    # Mock caption generation logic
    return "a man riding a bike"